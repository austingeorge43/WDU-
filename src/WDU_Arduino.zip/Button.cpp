#include <Arduino.h>
#include "Ext_Var.h"

float counter=0.0;
float calibration_value=3.0;
float speed=0.5;
float Max_liter=0.0;
float temp_error=0.0;
// float speed=1.0;
bool mainscreenflag=0;
bool usersettings=1;
bool uppointer=0;
bool downpointer=0;
bool inmenu=0;
bool secondaryyes=1;
bool solenoidoverride=0;
bool flowoverride=0;
bool speedup=0;
bool secondarytimerflag=0;
uint8_t longpress_count=0;
int Heatersafteytemp=50;


// bool in_usersettings=0;

//Button Pins
#define UP 35
#define DOWN 32
#define BACK 26
#define MODE 36


OneButton up_button(UP, true);
OneButton down_button(DOWN, true);
OneButton back_button(BACK, true);
OneButton mode_button(MODE, true);

//DEFINATION

buttonClass:: buttonClass()
{}

void buttonClass:: button_setup()
{
    pinMode(UP,INPUT_PULLUP);
    pinMode(DOWN,INPUT_PULLUP);
    pinMode(BACK,INPUT_PULLUP);
    pinMode(MODE,INPUT_PULLUP);
    
    up_button.attachClick(increment);
    up_button.attachDuringLongPress(long_press_up);
    down_button.attachClick(decrement);
    down_button.attachDuringLongPress(long_press_down);
    mode_button.attachDuringLongPress(user_settings);
    mode_button.attachClick(enter_function);
    back_button.attachClick(back_screen);
    back_button.setPressMs(1000);
    back_button.attachDuringLongPress(back_to_home);
    
//  
}

void buttonClass:: button_ticks()
{
    up_button.tick();
    down_button.tick();
    mode_button.tick();
    back_button.tick();
}

void buttonClass:: back_to_home()
{
    if(!mainscreenflag){
    lcd.clear();
    digitalWrite(BUZZER,HIGH);
    buzzerclass_object.Buzzer_beep(1000);
    buzzerclass_object.Buzzer_start();
    screen=MainScreen;
    usersettings=1;
    process_flag=0;
    secondarytimerflag=0;
    process_object.heater1_stop();
    buzzerclass_object.heater_stop();
    eeprom_object.eeprom_datawrite();
    // process_object.process_stop();
    }

}

void buttonClass::long_press_up()
{
    // counter+=0.5;
    if(mainscreenflag)
    {
    Max_liter=(2*optime[optimecounter])*(variant/10.0);
    if(counter<Max_liter)
    {
    longpress_count++;
    if(longpress_count==5)
    {
        counter+=0.5;
        longpress_count=0;
    }
    }
    }

    if(screen==CalibrationSettings)
    {
        Max_liter=(2*optime[optimecounter])*(variant/10.0);
        if(calibration_value<Max_liter)
        {
            longpress_count++;
            if(longpress_count==5)
            {
                calibration_value+=0.1;
                longpress_count=0;
            }
        }
    }
    
    if(screen==SafteyTemperatureSettings)
    {
        if(Heatersafteytemp<200)
        {
        longpress_count++;
        if(longpress_count==5)
        {
            Heatersafteytemp+=5;
            longpress_count=0;
        }
        }
    }

}

void buttonClass::long_press_down()
{
    if(counter>=0.5)
    {
        if(mainscreenflag)
        {
            longpress_count++;
            if(longpress_count==5)
            {
                counter-=0.5;
                longpress_count=0;
            }
        }
    }
    if(screen==CalibrationSettings)
    {
        if(calibration_value>0.0)
        {
            longpress_count++;
            if(longpress_count==5)
            {
                calibration_value-=0.1;
                longpress_count=0;
            }
        }
    }

    if(screen==SafteyTemperatureSettings)
    {
        if(Heatersafteytemp>50)
        {
        longpress_count++;
        if(longpress_count==5)
        {
            Heatersafteytemp-=5;
            longpress_count=0;
        }
        }
    }
    


}
void buttonClass::increment()
{
    if(mainscreenflag){
        Max_liter=(2*optime[optimecounter])*(variant/10.0);
        if(counter<Max_liter)
        {
        counter+=0.5;
        }
    }
    switch(screen)
    {
        case ProbeCalibrationSettings:
            temp_error+=0.1;

        break;


        case SafteyTemperatureSettings:
            if(Heatersafteytemp<200)
            {
            Heatersafteytemp+=5;
            }
        break;


        case SecondaryFillSettings:
            lcd.clear();
            lcd.setCursor(0,1);
            lcd.print(">");
            secondaryyes=1;
            break;
        
        case CalibrationSettings:
            calibration_value+=0.1;
            break;

        case UserSettingsScreen1:
            if(dduflag)
            {
                if(uppointer)
                {
                    screen=UserSettingsScreen7;
                    lcd.clear();
                    lcd.setCursor(0,1);
                    lcd.print(">");
                    uppointer=0;
                    downpointer=1;

                }
                else
                {
                    lcd.clear();
                    lcd.setCursor(0,0);
                    lcd.print(">");
                    uppointer=1;
                    downpointer=0;
                }
            }
            else
            {
                if(uppointer)
                {
                    screen=UserSettingsScreen4;
                    lcd.clear();
                    lcd.setCursor(0,1);
                    lcd.print(">");
                    uppointer=0;
                    downpointer=1;

                }
                else
                {
                    lcd.clear();
                    lcd.setCursor(0,0);
                    lcd.print(">");
                    uppointer=1;
                    downpointer=0;
                }

            }
            break;
        
        case UserSettingsScreen2:
            if(uppointer)
            {
              screen=UserSettingsScreen1;
              lcd.clear();
              lcd.setCursor(0,0);
              lcd.print(">");
              uppointer=1;
              downpointer=0;
            }
            else 
            {
              lcd.clear();
              lcd.setCursor(0,0);
              lcd.print(">");
              uppointer=1;
              downpointer=0;
            }
            break;

        case UserSettingsScreen3:
          if(uppointer)
            {
                screen=UserSettingsScreen2;
                lcd.clear();
                lcd.setCursor(0,0);
                lcd.print(">");
                uppointer=1;
                downpointer=0;
            }
            else
            {
                lcd.clear();
                lcd.setCursor(0,0);
                lcd.print(">");
                uppointer=1;
                downpointer=0;
            }
        break; 

        case UserSettingsScreen4:
          if(uppointer)
            {
                screen=UserSettingsScreen3;
                lcd.clear();
                lcd.setCursor(0,0);
                lcd.print(">");
                uppointer=1;
                downpointer=0;
            }
            else
            {
                lcd.clear();
                lcd.setCursor(0,0);
                lcd.print(">");
                uppointer=1;
                downpointer=0;
            }
        break;

        case UserSettingsScreen5:
          if(uppointer)
            {
                screen=UserSettingsScreen4;
                lcd.clear();
                lcd.setCursor(0,0);
                lcd.print(">");
                uppointer=1;
                downpointer=0;
            }
            else
            {
                lcd.clear();
                lcd.setCursor(0,0);
                lcd.print(">");
                uppointer=1;
                downpointer=0;
            }
        break;

        case UserSettingsScreen6:
          if(uppointer)
            {
                screen=UserSettingsScreen5;
                lcd.clear();
                lcd.setCursor(0,0);
                lcd.print(">");
                uppointer=1;
                downpointer=0;
            }
            else
            {
                lcd.clear();
                lcd.setCursor(0,0);
                lcd.print(">");
                uppointer=1;
                downpointer=0;
            }
        break;

        case UserSettingsScreen7:
          if(uppointer)
            {
                screen=UserSettingsScreen6;
                lcd.clear();
                lcd.setCursor(0,0);
                lcd.print(">");
                uppointer=1;
                downpointer=0;
            }
            else
            {
                lcd.clear();
                lcd.setCursor(0,0);
                lcd.print(">");
                uppointer=1;
                downpointer=0;
            }
        break;
        
        case OperatingTimeSettings:
            if(optimecounter<3){
            optimecounter++;
            }
            else
            {
                optimecounter=0;
            }
        break;

        case SubProductTypeSettings:
            if(prodtypecounter<2){
            prodtypecounter++;
            }
            else
            {
                prodtypecounter=0;
            }
        break;

        case SolenoidControlSettings:
            lcd.clear();
            lcd.setCursor(0,1);
            lcd.print("> Override");
            solenoidoverride=1;
        break;

        case FlowControlSettings:
            lcd.clear();
            lcd.setCursor(0,1);
            lcd.print("> Override");
            flowoverride=1;
        break;

        case ProductTypeSettings:
            lcd.clear();
            lcd.setCursor(0,1);
            lcd.print(">SDU    ");
            dduflag=0;
        break;
            
            
    }

}

void buttonClass::decrement()
{
 if(mainscreenflag){
    if(counter>0.0){
    // speed=0.5;
    counter-=0.5;
    }
  }

  switch(screen)
  {
    case ProbeCalibrationSettings:
            temp_error-=0.1;

    break;

    case SafteyTemperatureSettings:
        if(Heatersafteytemp>50)
        {
            Heatersafteytemp-=5;
        }    
    break;

    case SecondaryFillSettings:
        lcd.clear();
        lcd.setCursor(11,1);
        lcd.print(">");
        secondaryyes=0;
    break;

    case SolenoidControlSettings:
            lcd.clear();
            lcd.setCursor(0,1);
            lcd.print("> Active    ");
            solenoidoverride=0;
        break;

    case FlowControlSettings:
        lcd.clear();
        lcd.setCursor(0,1);
        lcd.print("> Active    ");
        flowoverride=0;
    break;

    case CalibrationSettings:
        if(calibration_value>0.0)
        {
        calibration_value-=0.1;
        }
    break;

    case UserSettingsScreen7:
        if(downpointer)
        {
            screen=UserSettingsScreen1;
            lcd.clear();
            lcd.setCursor(0,0);
            lcd.print(">");
            downpointer=0;
            uppointer=1;   
        }
        else
        {
        lcd.clear();
        lcd.setCursor(0,1);
        lcd.print(">");
        downpointer=1;
        uppointer=0;
        }
    break;

    case UserSettingsScreen6:
        if(downpointer)
        {
            screen=UserSettingsScreen7;
            lcd.clear();
            lcd.setCursor(0,1);
            lcd.print(">");
            downpointer=1;
            uppointer=0;   
        }
        else
        {
        lcd.clear();
        lcd.setCursor(0,1);
        lcd.print(">");
        downpointer=1;
        uppointer=0;
        }
    break;

    case UserSettingsScreen5:
        if(downpointer)
        {
            screen=UserSettingsScreen6;
            lcd.clear();
            lcd.setCursor(0,1);
            lcd.print(">");
            downpointer=1;
            uppointer=0;   
        }
        else
        {
        lcd.clear();
        lcd.setCursor(0,1);
        lcd.print(">");
        downpointer=1;
        uppointer=0;
        }
    break;

    case UserSettingsScreen4:
        if(dduflag)
        {
            if(downpointer)
            {
                lcd.clear();
                screen=UserSettingsScreen5;
            
                lcd.setCursor(0,1);
                lcd.print(">");
                uppointer=0;
                downpointer=1;   
            }
            else
            {
                lcd.clear();
                lcd.setCursor(0,1);
                lcd.print(">");
                uppointer=0;
                downpointer=1;
            }
        }
        else
        {
             if(downpointer)
            {
                lcd.clear();
                screen=UserSettingsScreen1;
            
                lcd.setCursor(0,0);
                lcd.print(">");
                uppointer=1;
                downpointer=0;   
            }
            else
            {
                lcd.clear();
                lcd.setCursor(0,1);
                lcd.print(">");
                uppointer=0;
                downpointer=1;
            }

        }
    break;

    case UserSettingsScreen3:
        if(downpointer)
        {
            screen=UserSettingsScreen4;
            lcd.clear();
            lcd.setCursor(0,1);
            lcd.print(">");
            downpointer=1;
            uppointer=0;   
        }
        else
        {
            lcd.clear();
            lcd.setCursor(0,1);
            lcd.print(">");
            downpointer=1;
            uppointer=0;
        }
    break;

    case UserSettingsScreen2:
         if(downpointer)
        {
            screen=UserSettingsScreen3;
            lcd.clear();
            lcd.setCursor(0,1);
            lcd.print(">");
            downpointer=1;
            uppointer=0;
        }
        else
        {
           lcd.clear();
           lcd.setCursor(0,1);
           lcd.print(">");
           downpointer=1;
           uppointer=0; 
        }
    break;

    case UserSettingsScreen1:
        if(downpointer)
        {
            screen=UserSettingsScreen2;
            lcd.clear();
            lcd.setCursor(0,1);
            lcd.print(">");
            downpointer=1;
            
        }
        else
        {
            lcd.clear();
            lcd.setCursor(0,1);
            lcd.print(">");
            downpointer=1;
            uppointer=0;
        }
    break;

    case OperatingTimeSettings:
            if(optimecounter>0){
            optimecounter--;
            }
            else{
                optimecounter=3;
            }
        break;

    case SubProductTypeSettings:
            if(prodtypecounter>0){
            prodtypecounter--;
            }
            else{
                prodtypecounter=2;
            }
    break;

    case ProductTypeSettings:
            lcd.clear();
            lcd.setCursor(11,1);
            lcd.print(">DDU    ");
            dduflag=1;
    break;
  }
}

void buttonClass:: user_settings()
{
   
    if(usersettings && !process_flag){
      lcd.clear();
      screen=UserSettingsScreen1;
      usersettings=0;
      digitalWrite(BUZZER,HIGH);
      buzzerclass_object.Buzzer_beep(1000);
      buzzerclass_object.Buzzer_start();
      lcd.clear();
      lcd.setCursor(0,0);
      lcd.print(">");
      uppointer=1;
    }

   
}

void buttonClass:: back_screen()
{
    if(!usersettings && !inmenu){
        lcd.clear();
        eeprom_object.eeprom_datawrite();
        screen=MainScreen;
        mainscreenflag=1;
        usersettings=1;
        uppointer=0;
        downpointer=0;
    }

    if(inmenu)
    {
        lcd.clear();
        screen=UserSettingsScreen1;
        inmenu=0;
        lcd.setCursor(0,0);
        lcd.print(">");
        uppointer=1;
        downpointer=0;
    }
}

void buttonClass::enter_function()
{
    if(mainscreenflag)
    {
        process_object.variant_settings();
        // lcd.clear();
        Serial3.println("BUZZZZZZZZZZZER");
        digitalWrite(BUZZER,HIGH);
        // delay(500);
        buzzerclass_object.Buzzer_beep(1000);
        buzzerclass_object.Buzzer_start();
        
        // screen=ProcessScreen;
        //     process_flag=1;
        //     mainscreenflag=0;
        //     one_second_counter=0;
        //     pauseflag=0;
        //     error_check_flag=0;
        //     flow_error_checkflag=0;

        if(secondaryyes && dduflag)
        {
            
            // Serial3.println("Secondary Fill");
            screen=SecondaryFillTimer;
            mainscreenflag=0;
            one_second_counter=0;
            secondarytimerflag=1;
            pauseflag=0;
            error_check_flag=0;
            process_object.heater1_start();
            // flow_error_checkflag=0;
        }
        else
        {
            screen=ProcessScreen;
            process_flag=1;
            mainscreenflag=0;
            one_second_counter=0;
            pauseflag=0;
            error_check_flag=0;
            process_object.heater1_start();
            if(dduflag){
            buzzerclass_object.heater_start();
            }
            // flow_error_checkflag=0;
            // TCA0.SINGLE.INTFLAGS = TCA_SINGLE_OVF_bm;
        }
    }
    if(screen==FlowControlSettings || screen==SolenoidControlSettings || screen==ProductTypeSettings || screen==OperatingTimeSettings || screen==CalibrationSettings || screen==SecondaryFillSettings || screen==SafteyTemperatureSettings || screen==ProbeCalibrationSettings || screen==SubProductTypeSettings )
    {
        lcd.clear();
        screen=UserSettingsScreen1;
        usersettings=1;
        uppointer=1;
        downpointer=0;
        lcd.setCursor(0,0);
        lcd.print(">");
        inmenu=0;
    }

    // if(screen==SecondaryFillSettings)
    // {
    //      if(secondaryyes)
    //     {
    //         process_object.variant_settings();
    //         // Serial3.println("Secondary Fill");
    //         screen=SecondaryFillTimer;
    //         mainscreenflag=0;
    //         one_second_counter=0;
    //         secondarytimerflag=1;
    //         pauseflag=0;
    //         error_check_flag=0;
    //         flow_error_checkflag=0;
    //         usersettings=1;
    //         inmenu=0;
    //     }

    // }

    if(!usersettings)
    {
        switch(screen)
        {
            case UserSettingsScreen1:
                if(!downpointer)
                {
                    lcd.clear();
                    screen=ProductTypeSettings;
                    inmenu=1;
                    if(dduflag)
                    {
                        lcd.setCursor(11,1);
                        lcd.print(">");
                    }
                    else
                    {
                        lcd.setCursor(0,1);
                        lcd.print(">");  
                    }
                }
                else
                {
                    lcd.clear();
                    screen=SubProductTypeSettings;
                    inmenu=1;
                }
            break;

            case UserSettingsScreen2:
                if(downpointer)
                {
                    screen=CalibrationSettings;
                    lcd.clear();
                    inmenu=1;
                }
                else
                {
                     lcd.clear();
                    screen=SubProductTypeSettings;
                    inmenu=1;

                }
            break;

            case UserSettingsScreen3:
            
                if(downpointer)
                {
                    lcd.clear();
                    screen=SolenoidControlSettings;
                    if(solenoidoverride)
                    {
                        lcd.setCursor(0,1);
                        lcd.print("> Override"); 
                    }
                    else
                    {
                    lcd.setCursor(0,1);
                    lcd.print("> Active   ");
                    }
                    inmenu=1;
                }
                else
                {
                    screen=CalibrationSettings;
                    lcd.clear();
                    inmenu=1;
                   
                }
            break;

            case UserSettingsScreen4:
                if(downpointer)
                {
                    lcd.clear();
                    screen=FlowControlSettings;
                    if(flowoverride)
                    {
                        lcd.setCursor(0,1);
                        lcd.print("> Override"); 
                    }
                    else
                    {
                    lcd.setCursor(0,1);
                    lcd.print("> Active   ");
                    }
                    inmenu=1;

                }
                else
                {
                    lcd.clear();
                    screen=SolenoidControlSettings;
                    if(solenoidoverride)
                    {
                        lcd.setCursor(0,1);
                        lcd.print("> Override"); 
                    }
                    else
                    {
                    lcd.setCursor(0,1);
                    lcd.print("> Active   ");
                    }
                    inmenu=1;
                }
            break;

            case UserSettingsScreen5:
                if(downpointer)
                {
                    lcd.clear();
                    screen=SecondaryFillSettings;
                    inmenu=1;
                    if(secondaryyes)
                    {
                        lcd.setCursor(0,1);
                        lcd.print(">");
                    }
                    else
                    {
                        lcd.setCursor(11,1);
                        lcd.print(">");  
                    }

                }
                else
                {
                    lcd.clear();
                    screen=FlowControlSettings;
                    if(flowoverride)
                    {
                        lcd.setCursor(0,1);
                        lcd.print("> Override"); 
                    }
                    else
                    {
                    lcd.setCursor(0,1);
                    lcd.print("> Active   ");
                    }
                    inmenu=1;
                }
            break;

            case UserSettingsScreen6:
                if(downpointer)
                {
                    lcd.clear();
                    screen=SafteyTemperatureSettings;
                    inmenu=1;

                }
                else
                {
                    lcd.clear();
                    screen=SecondaryFillSettings;
                    inmenu=1;
                    if(secondaryyes)
                    {
                        lcd.setCursor(0,1);
                        lcd.print(">");
                    }
                    else
                    {
                        lcd.setCursor(11,1);
                        lcd.print(">");  
                    }
                }
            break;

            case UserSettingsScreen7:
                if(downpointer)
                {
                    lcd.clear();
                    screen=ProbeCalibrationSettings;
                    inmenu=1;

                }
                else
                {
                    lcd.clear();
                    screen=SafteyTemperatureSettings;
                    inmenu=1;

                }
            break;

        }
        // switch(screen)
        // {
        //     case UserSettingsScreen1:
        //         if(!downpointer)
        //         {
        //             lcd.clear();
        //             screen=SecondaryFillSettings;
        //             inmenu=1;
        //             if(secondaryyes)
        //             {
        //                 lcd.setCursor(0,1);
        //                 lcd.print(">");
        //             }
        //             else
        //             {
        //                 lcd.setCursor(11,1);
        //                 lcd.print(">");  
        //             }
        //         }
        //         else
        //         {
        //             lcd.clear();
        //             screen=SafteyTemperatureSettings;
        //             inmenu=1;
        //         }
        //     break;

        //     case UserSettingsScreen2:
        //         if(downpointer)
        //         {
        //             screen=ProbeCalibrationSettings;
        //             lcd.clear();
        //             inmenu=1;
        //         }
        //         else
        //         {
        //             lcd.clear();
        //             screen=SafteyTemperatureSettings;
        //             inmenu=1;

        //         }
        //     break;

        //     case UserSettingsScreen3:
            
        //         if(downpointer)
        //         {
        //             screen=CalibrationSettings;
        //             lcd.clear();
        //             inmenu=1;
        //         }
        //         else
        //         {
        //             lcd.clear();
        //             screen=SafteyTemperatureSettings;
        //             inmenu=1;

        //         }
        //     break;

        //     case UserSettingsScreen4:
        //         if(downpointer)
        //         {
        //             lcd.clear();
        //             screen=ProductTypeSettings;
        //             inmenu=1;

        //         }
        //         else
        //         {
        //             screen=CalibrationSettings;
        //             lcd.clear();
        //             inmenu=1;
        //         }
        //     break;

        //     case UserSettingsScreen5:
        //         if(downpointer)
        //         {
        //             lcd.clear();
        //             screen=SolenoidControlSettings;
        //             if(solenoidoverride)
        //             {
        //                 lcd.setCursor(0,1);
        //                 lcd.print("> Override"); 
        //             }
        //             else
        //             {
        //             lcd.setCursor(0,1);
        //             lcd.print("> Active   ");
        //             }
        //             inmenu=1;

        //         }
        //         else
        //         {
        //             lcd.clear();
        //             screen=ProductTypeSettings;
        //             inmenu=1;

        //         }
        //     break;

        //     case UserSettingsScreen6:
        //         if(downpointer)
        //         {
        //             lcd.clear();
        //             screen=FlowControlSettings;
        //             if(flowoverride)
        //             {
        //                 lcd.setCursor(0,1);
        //                 lcd.print("> Override"); 
        //             }
        //             else
        //             {
        //             lcd.setCursor(0,1);
        //             lcd.print("> Active   ");
        //             }
        //             inmenu=1;

        //         }
        //         else
        //         {
        //             lcd.clear();
        //             screen=SolenoidControlSettings;
        //             if(solenoidoverride)
        //             {
        //                 lcd.setCursor(0,1);
        //                 lcd.print("> Override"); 
        //             }
        //             else
        //             {
        //             lcd.setCursor(0,1);
        //             lcd.print("> Active   ");
        //             }
        //             inmenu=1;
        //         }
        //     break;

        //     case UserSettingsScreen7:
        //         if(downpointer)
        //         {
        //             lcd.clear();
        //             screen=OperatingTimeSettings;
        //             inmenu=1;

        //         }
        //         else
        //         {
        //             lcd.clear();
        //             screen=FlowControlSettings;
        //             if(flowoverride)
        //             {
        //                 lcd.setCursor(0,1);
        //                 lcd.print("> Override"); 
        //             }
        //             else
        //             {
        //             lcd.setCursor(0,1);
        //             lcd.print("> Active   ");
        //             }
        //             inmenu=1;
        //         }
        //     break;



        // }
        
    }
}


buttonClass buttonClass_object = buttonClass();