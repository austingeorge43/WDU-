#include <Arduino.h>
#include "Ext_Var.h"

#include <EEPROM.h>


#define PRODUCT_SELECTION 0
#define SUBPRODUCT_SELECTION 1
#define SAFETY_TEMP 3
#define CALIBRATION_VALUE 5
#define PROBE_ERROR 9

//----------DEFINATIONS

eepromclass::eepromclass()
{}

void eepromclass:: eeprom_datawrite()
{
  
    EEPROM.write(PRODUCT_SELECTION, dduflag);
    EEPROM.put(SUBPRODUCT_SELECTION,prodtypecounter);
    
    EEPROM.put(CALIBRATION_VALUE, calibration_value);
    // Heatersafteytemp=50;
    EEPROM.put(SAFETY_TEMP, Heatersafteytemp);
    // temp_error=0.0;
    EEPROM.put(PROBE_ERROR, temp_error);

}

void eepromclass :: eeprom_dataread()
{
    dduflag=EEPROM.read(PRODUCT_SELECTION);
    EEPROM.get(SUBPRODUCT_SELECTION,prodtypecounter);
    EEPROM.get(CALIBRATION_VALUE, calibration_value);
    EEPROM.get(SAFETY_TEMP, Heatersafteytemp);
    EEPROM.get(PROBE_ERROR, temp_error);

    // Serial3.println(dduflag);
    // Serial3.println(calibration_value);

}

eepromclass eeprom_object= eepromclass();